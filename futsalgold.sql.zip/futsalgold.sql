--
-- Database: `futsalgold`
--

-- --------------------------------------------------------

--
-- Table structure for table `2padmin`
--

CREATE TABLE `2padmin` (
  `Nama` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Username` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Password` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Jabatan` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Level` int(10) NOT NULL,
  `Foto` blob NOT NULL,
  `Temp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `2padmin`
--

INSERT INTO `2padmin` (`Nama`, `Username`, `Password`, `Jabatan`, `Level`, `Foto`, `Temp`, `ID`) VALUES
('Admin', 'admin', 'admin', 'Supervisor', -1, '', '2013-09-02 13:43:42', 1),
('Op2', 'op2', 'op1', 'Operator', 1, '', '2013-09-03 13:52:56', 38),
('Op1', 'op1', 'op1', 'Operator', 1, '', '2013-09-03 13:53:01', 35),
('Op3', 'op3', 'op3', 'Operator', 1, '', '2013-09-03 13:53:07', 60);

-- --------------------------------------------------------

--
-- Table structure for table `2pbackup`
--

CREATE TABLE `2pbackup` (
  `ID` int(11) NOT NULL,
  `DBPath` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ToPath` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `2pbackup`
--

INSERT INTO `2pbackup` (`ID`, `DBPath`, `ToPath`) VALUES
(1, 'E:\\xampp\\mysql\\data\\pointofsalenew', 'E:\\Aplikasi\\PointOfSaleNew\\Backup PointOfSale');

-- --------------------------------------------------------

--
-- Table structure for table `daftar lapangan`
--

CREATE TABLE `daftar lapangan` (
  `ID` int(11) NOT NULL,
  `Kode` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `NamaLapangan` varchar(100) COLLATE latin1_general_ci DEFAULT '-',
  `Ukuran` varchar(100) COLLATE latin1_general_ci DEFAULT '-',
  `Kondisi` varchar(100) COLLATE latin1_general_ci DEFAULT '-',
  `HargaSewa1` int(50) DEFAULT '0',
  `HargaSewa2` int(50) DEFAULT '0',
  `HargaSewa3` int(50) DEFAULT '0',
  `HargaSewa4` int(50) DEFAULT '0',
  `HargaSewa5` int(50) DEFAULT '0',
  `Member` int(10) DEFAULT '0',
  `NonMember` int(10) DEFAULT '0',
  `Waktu` datetime DEFAULT NULL,
  `Stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `daftar lapangan`
--

INSERT INTO `daftar lapangan` (`ID`, `Kode`, `NamaLapangan`, `Ukuran`, `Kondisi`, `HargaSewa1`, `HargaSewa2`, `HargaSewa3`, `HargaSewa4`, `HargaSewa5`, `Member`, `NonMember`, `Waktu`, `Stamp`) VALUES
(1, 'L-001', 'Lapangan Euro', '16x26', 'Baik', 80000, 125000, 70000, 115000, 0, 72000, 200, '0000-00-00 00:00:00', '2013-09-03 08:00:20'),
(2, 'L-002', 'Lapangan Olimpico', '15x25', 'Baik', 70000, 100000, 60000, 90000, 0, 10, 100, '0000-00-00 00:00:00', '2013-09-03 08:00:30'),
(4, 'L-003', 'Lap B', '-', 'Baik', 80000, 80000, 100000, 100000, 0, 0, 0, NULL, '2013-12-14 12:52:07');

-- --------------------------------------------------------

--
-- Table structure for table `daftar pelanggan`
--

CREATE TABLE `daftar pelanggan` (
  `ID` int(11) NOT NULL,
  `Kode` varchar(255) COLLATE latin1_general_ci DEFAULT '-',
  `NamaPenyewa` varchar(255) COLLATE latin1_general_ci DEFAULT '-',
  `NamaTeam` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `Alamat` text COLLATE latin1_general_ci,
  `Kota` varchar(255) COLLATE latin1_general_ci DEFAULT '-',
  `Telepon` varchar(255) COLLATE latin1_general_ci DEFAULT '-',
  `Fax` varchar(255) COLLATE latin1_general_ci DEFAULT '-',
  `HP` varchar(255) COLLATE latin1_general_ci DEFAULT '-',
  `Email` varchar(255) COLLATE latin1_general_ci DEFAULT '-',
  `Website` varchar(255) COLLATE latin1_general_ci DEFAULT '-',
  `Main` int(50) DEFAULT '0',
  `Waktu` datetime DEFAULT NULL,
  `Stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `daftar pelanggan`
--

INSERT INTO `daftar pelanggan` (`ID`, `Kode`, `NamaPenyewa`, `NamaTeam`, `Alamat`, `Kota`, `Telepon`, `Fax`, `HP`, `Email`, `Website`, `Main`, `Waktu`, `Stamp`) VALUES
(8, 'C-001', 'Nama1', 'xxx', '', 'Kota1', 'Telepon1', '-', '-', '-', '-', 3, '2013-04-17 11:33:57', '2013-09-02 14:24:51'),
(9, 'C-002', 'Nama2', '', '', 'Kota2', 'Telepon2', '-', '-', '-', '-', 0, '2013-04-17 11:33:57', '2013-09-02 14:24:58'),
(10, 'C-003', 'Nama3', '', '', 'Kota3', 'Telepon3', '-', '-', '-', '-', 2, '2013-04-17 11:33:57', '2013-09-02 14:25:05'),
(11, 'C-004', 'Nama4', 'Team4', NULL, 'Jakarta', '123', '-', '-', '-', '-', 0, NULL, '2013-12-14 12:54:01');

-- --------------------------------------------------------

--
-- Table structure for table `daftar produk`
--

CREATE TABLE `daftar produk` (
  `ID` int(11) NOT NULL,
  `TglStok` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `Kode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Nama Barang` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Isi` int(11) NOT NULL,
  `Satuan` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Berat` double DEFAULT NULL,
  `Harga Pokok` int(11) NOT NULL,
  `Harga Jual` int(11) NOT NULL,
  `Jumlah` int(11) NOT NULL,
  `Jumlah Total` int(11) NOT NULL,
  `Supplier` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `Departemen` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `Foto` blob NOT NULL,
  `Waktu` datetime NOT NULL,
  `Stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `daftar produk`
--

INSERT INTO `daftar produk` (`ID`, `TglStok`, `Kode`, `Nama Barang`, `Isi`, `Satuan`, `Berat`, `Harga Pokok`, `Harga Jual`, `Jumlah`, `Jumlah Total`, `Supplier`, `Departemen`, `Foto`, `Waktu`, `Stamp`) VALUES
(553, '', 'P-001', 'Produk1', 5, 'Buah', 1, 5000, 6000, 100, 100, 'S-001', '', '', '2013-04-16 23:33:53', '2013-09-04 16:03:15'),
(554, '', 'P-002', 'Produk2', 3, 'Buah', 2, 6000, 7000, 100, 100, 'S-001', '', '', '2013-04-16 20:52:05', '2013-07-19 23:31:29'),
(555, '', 'P-003', 'Produk3', 1, 'Buah', 2.5, 7000, 8000, 100, 100, 'S-002', '', '', '2013-04-24 14:59:49', '2013-07-19 23:51:10'),
(589, '', 'P-004', 'Produk4', 1, 'Buah', 3, 8000, 9000, 100, 0, 'S-001', '', '', '0000-00-00 00:00:00', '2013-07-22 15:32:11'),
(590, '', 'P-005', 'Produk5', 0, 'Buah', NULL, 8000, 9000, 100, 0, 'S-003', '', '', '0000-00-00 00:00:00', '2013-12-14 12:55:44');

-- --------------------------------------------------------

--
-- Table structure for table `daftar satuan`
--

CREATE TABLE `daftar satuan` (
  `ID` int(11) NOT NULL,
  `Satuan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daftar satuan`
--

INSERT INTO `daftar satuan` (`ID`, `Satuan`) VALUES
(1, 'KG'),
(2, 'Buah'),
(3, 'Botol');

-- --------------------------------------------------------

--
-- Table structure for table `daftar suplier`
--

CREATE TABLE `daftar suplier` (
  `ID` int(11) NOT NULL,
  `Kode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Nama` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Alamat` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Kota` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Telepon` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Fax` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `HP` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Website` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Waktu` datetime NOT NULL,
  `Stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `daftar suplier`
--

INSERT INTO `daftar suplier` (`ID`, `Kode`, `Nama`, `Alamat`, `Kota`, `Telepon`, `Fax`, `HP`, `Email`, `Website`, `Waktu`, `Stamp`) VALUES
(21, 'S-003', 'Nama3', '-', '-', '-', '-', '-', 'a@a.com', '-', '0000-00-00 00:00:00', '2013-07-17 14:33:58'),
(13, 'S-002', 'Nama2', '-', '-', '-', '-', '-', 'a@a.com', '-', '2012-12-24 11:10:10', '2013-07-17 14:35:07'),
(12, 'S-001', 'Nama1', '-', '-', '-', '-', '-', 'a@a.com', '-', '2012-12-24 11:10:01', '2013-07-17 14:32:04'),
(22, 'S-004', 'Nama4', '-', '-', '-', '-', '-', 'a@a.com', '-', '0000-00-00 00:00:00', '2013-07-17 14:36:00');

-- --------------------------------------------------------

--
-- Table structure for table `lapstok`
--

CREATE TABLE `lapstok` (
  `ID` int(11) NOT NULL,
  `TglDari` date NOT NULL,
  `TglKe` date NOT NULL,
  `Laporan` varchar(100) NOT NULL DEFAULT 'Buka Laporan'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lapstok`
--

INSERT INTO `lapstok` (`ID`, `TglDari`, `TglKe`, `Laporan`) VALUES
(1, '2013-12-01', '2013-12-31', 'Buka Laporan');

-- --------------------------------------------------------

--
-- Table structure for table `lic`
--

CREATE TABLE `lic` (
  `ID` int(11) NOT NULL,
  `Serial` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `Kode` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `Status` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `Waktu` datetime NOT NULL,
  `Stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `lic`
--

INSERT INTO `lic` (`ID`, `Serial`, `Kode`, `Status`, `Waktu`, `Stamp`) VALUES
(2, 'MS-121675810', '90acc730d6cd99fd4916b6a93293f839', 'Registered', '0000-00-00 00:00:00', '2013-04-22 12:26:26');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `ID` int(11) NOT NULL,
  `MainMenu` varchar(100) NOT NULL,
  `Link` varchar(255) NOT NULL,
  `No` int(10) NOT NULL DEFAULT '0',
  `Akses` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`ID`, `MainMenu`, `Link`, `No`, `Akses`) VALUES
(1, 'Home', 'index.php', 1, '0'),
(3, 'Logout', 'logout.php', 10, '9,1'),
(2, 'Menu', '_menulist.php', 8, '9'),
(5, 'Master', '#', 1, '9,1'),
(6, 'Persewaan', '#', 2, '9,1'),
(7, 'Laporan', '#', 5, '9'),
(8, 'Setting', '#', 6, '9'),
(9, 'Tools', '#', 7, '9'),
(10, 'Help', 'AppHelp.php', 9, '9'),
(11, 'Booking', '#', 3, '9,1'),
(12, 'Kantin', '#', 4, '9,1');

-- --------------------------------------------------------

--
-- Table structure for table `menusub1`
--

CREATE TABLE `menusub1` (
  `ID` int(11) NOT NULL,
  `Menu` varchar(100) NOT NULL,
  `Link` varchar(255) NOT NULL,
  `Parent` varchar(100) NOT NULL,
  `No` int(10) NOT NULL DEFAULT '0',
  `Akses` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menusub1`
--

INSERT INTO `menusub1` (`ID`, `Menu`, `Link`, `Parent`, `No`, `Akses`) VALUES
(21, 'Sewa Lapangan / Booking', 'persewaan_lapangan_2D_masterlist.php?t=persewaan_lapangan_2D_master&z_Status=LIKE&x_Status=Booking&psearch=&Submit=Search+%28*%29&psearchtype=', 'Persewaan', 1, '9,1'),
(20, 'Satuan', 'daftar_satuanlist.php', 'Master', 5, '9,1'),
(16, 'Lapangan', 'daftar_lapanganlist.php', 'Master', 1, '9,1'),
(17, 'Pelanggan', 'daftar_pelangganlist.php', 'Master', 2, '9,1'),
(18, 'Produk Kantin', 'daftar_produklist.php', 'Master', 3, '9,1'),
(19, 'Suplier Kantin', 'daftar_suplierlist.php', 'Master', 4, '9,1'),
(27, 'Master', '#', 'Laporan', 1, '9'),
(11, 'Admin', '_2padminedit.php', 'Setting', 1, '9'),
(12, 'Profil', 'profileedit.php?ID=1', 'Setting', 2, '9'),
(13, 'Backup', 'AppBackup.php', 'Tools', 1, '9'),
(14, 'Restore', 'AppRestore.php', 'Tools', 2, '9'),
(15, 'Reset Data', 'AppReset.php', 'Tools', 3, '9'),
(22, 'Browse Semua Transaksi', 'persewaan_lapangan_2D_masterlist.php?cmd=reset', 'Persewaan', 2, '9,1'),
(23, 'Transaksi Baru', 'persewaan_lapangan_2D_masteradd.php', 'Persewaan', 3, '9,1'),
(24, 'Jadwal / Daftar Booking Lapangan', 'Bookinglist.php?cmd=reset', 'Booking', 1, '9,1'),
(25, 'Penjualan', 'penjualan_2D_masterlist.php', 'Kantin', 1, '9,1'),
(26, 'Pembelian / Tambah Stok', 'pembelian_2D_masterlist.php', 'Kantin', 2, '9,1'),
(28, 'Persewaan', '#', 'Laporan', 2, '9'),
(29, 'Kantin', '#', 'Laporan', 3, '9');

-- --------------------------------------------------------

--
-- Table structure for table `menusub2`
--

CREATE TABLE `menusub2` (
  `ID` int(11) NOT NULL,
  `Menu` varchar(100) NOT NULL,
  `Link` varchar(255) NOT NULL,
  `Parent` varchar(100) NOT NULL,
  `No` int(10) NOT NULL DEFAULT '0',
  `Akses` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menusub2`
--

INSERT INTO `menusub2` (`ID`, `Menu`, `Link`, `Parent`, `No`, `Akses`) VALUES
(10, 'Browse Transaksi Belum Lunas', 'Sisa_Bayarlist.php', 'Persewaan', 2, '9'),
(9, 'Browse Rekapitulasi Persewaan', 'Rekapitulasi_Persewaanlist.php', 'Persewaan', 1, '9'),
(8, 'Master Pelanggan', 'Laporan_Daftar_Pelangganreport.php', 'Master', 2, '9,1'),
(7, 'Master Lapangan', 'Laporan_Daftar_Lapanganreport.php', 'Master', 1, '9,1'),
(11, 'Rekapitulasi Penjualan', 'Rekapitulasi_Penjualanlist.php', 'Kantin', 1, '9'),
(12, 'Rekapitulasi Pembelian', 'Rekapitulasi_Pembelianlist.php', 'Kantin', 2, '9'),
(13, 'Stok Barang Kantin', 'lapstokedit.php?ID=1', 'Kantin', 3, '9'),
(14, 'Penjualan Belum Lunas', 'Penjualan_Belum_Lunaslist.php', 'Kantin', 4, '9'),
(15, 'Pembelian Belum Lunas', 'Pembelian_Belum_Lunaslist.php', 'Kantin', 5, '9');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian - detail`
--

CREATE TABLE `pembelian - detail` (
  `ID` int(11) NOT NULL,
  `Kode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Nama Barang` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Isi` double NOT NULL,
  `Satuan` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Harga Beli` int(11) NOT NULL,
  `Jumlah` double NOT NULL,
  `Total Jumlah` double NOT NULL,
  `Berat` double NOT NULL DEFAULT '0',
  `Diskon` int(11) NOT NULL,
  `Total HP` int(100) NOT NULL,
  `Retur` int(11) NOT NULL DEFAULT '0',
  `User` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `Waktu` datetime NOT NULL,
  `Stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `IDM` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `pembelian - detail`
--

INSERT INTO `pembelian - detail` (`ID`, `Kode`, `Nama Barang`, `Isi`, `Satuan`, `Harga Beli`, `Jumlah`, `Total Jumlah`, `Berat`, `Diskon`, `Total HP`, `Retur`, `User`, `Waktu`, `Stamp`, `IDM`) VALUES
(1, 'P-001', 'Produk1', 0, 'Buah', 5000, 10, 0, 0, 0, 50000, 0, '', '0000-00-00 00:00:00', '2013-12-08 13:28:58', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pembelian - master`
--

CREATE TABLE `pembelian - master` (
  `ID` int(11) NOT NULL,
  `Faktur` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `No Faktur` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Diskon` double NOT NULL DEFAULT '0',
  `Ppn` int(11) NOT NULL DEFAULT '0',
  `Ongkir` int(11) NOT NULL DEFAULT '0',
  `Paking` int(11) NOT NULL DEFAULT '0',
  `Lain - lain` int(11) NOT NULL DEFAULT '0',
  `Hutang` int(100) NOT NULL DEFAULT '0',
  `Total Berat` double NOT NULL DEFAULT '0',
  `Total HP` int(100) NOT NULL DEFAULT '0',
  `Total HJ` int(100) DEFAULT NULL,
  `Grand Total` int(11) NOT NULL DEFAULT '0',
  `Dibayar` int(11) NOT NULL DEFAULT '0',
  `Kembali` int(11) NOT NULL DEFAULT '0',
  `SisaDibayar` int(11) NOT NULL DEFAULT '0',
  `Kode Kasir` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Nama Kasir` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Kode Supplier` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Nama Supplier` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Nama Form` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT 'Pembelian',
  `Tgl` date NOT NULL,
  `No` int(11) NOT NULL,
  `Hitung` varchar(50) COLLATE latin1_general_ci DEFAULT 'Hitung',
  `Waktu` datetime NOT NULL,
  `Stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `pembelian - master`
--

INSERT INTO `pembelian - master` (`ID`, `Faktur`, `No Faktur`, `Diskon`, `Ppn`, `Ongkir`, `Paking`, `Lain - lain`, `Hutang`, `Total Berat`, `Total HP`, `Total HJ`, `Grand Total`, `Dibayar`, `Kembali`, `SisaDibayar`, `Kode Kasir`, `Nama Kasir`, `Kode Supplier`, `Nama Supplier`, `Nama Form`, `Tgl`, `No`, `Hitung`, `Waktu`, `Stamp`) VALUES
(1, '', 'B-1', 0, 0, 0, 0, 0, 0, 0, 50000, NULL, 50000, 100000, 0, 0, 'admin', '', 'S-001', '', 'Pembelian', '2013-12-08', 1, 'Hitung', '0000-00-00 00:00:00', '2013-12-09 04:54:53');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan - detail`
--

CREATE TABLE `penjualan - detail` (
  `ID` int(11) NOT NULL,
  `Kode` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama Barang` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Isi` double NOT NULL DEFAULT '1',
  `Satuan` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Harga Pokok` int(11) NOT NULL DEFAULT '0',
  `Harga Jual` int(11) NOT NULL DEFAULT '0',
  `Jumlah` double NOT NULL DEFAULT '1',
  `Total Jumlah` double NOT NULL DEFAULT '0',
  `Berat` double NOT NULL DEFAULT '0',
  `Diskon` double NOT NULL DEFAULT '0',
  `Total HP` int(11) DEFAULT '0',
  `Total HJ` int(11) DEFAULT '0',
  `Saldo` int(11) DEFAULT '0',
  `Retur` int(10) NOT NULL DEFAULT '0',
  `User` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `IDM` int(11) NOT NULL,
  `Waktu` datetime NOT NULL,
  `Stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `penjualan - detail`
--

INSERT INTO `penjualan - detail` (`ID`, `Kode`, `Nama Barang`, `Isi`, `Satuan`, `Harga Pokok`, `Harga Jual`, `Jumlah`, `Total Jumlah`, `Berat`, `Diskon`, `Total HP`, `Total HJ`, `Saldo`, `Retur`, `User`, `IDM`, `Waktu`, `Stamp`) VALUES
(1, 'P-001', 'Produk1', 1, 'Buah', 5000, 6000, 1, 0, 0, 0, 5000, 6000, 0, 0, '', 1, '0000-00-00 00:00:00', '2013-12-08 13:27:01'),
(2, 'P-002', 'Produk2', 1, 'Buah', 6000, 7000, 5, 0, 0, 0, 30000, 35000, 0, 0, '', 1, '0000-00-00 00:00:00', '2013-12-08 13:28:12'),
(3, 'P-001', 'Produk1', 1, 'Buah', 5000, 6000, 3, 0, 0, 0, 15000, 18000, 0, 0, '', 2, '0000-00-00 00:00:00', '2013-12-14 13:31:35');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan - master`
--

CREATE TABLE `penjualan - master` (
  `ID` int(11) NOT NULL,
  `Faktur` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `No Faktur` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Diskon` double NOT NULL DEFAULT '0',
  `Ppn` int(11) NOT NULL DEFAULT '0',
  `Ongkir` int(11) NOT NULL DEFAULT '0',
  `Paking` int(11) NOT NULL DEFAULT '0',
  `Lain - lain` int(11) NOT NULL DEFAULT '0',
  `Piutang` int(100) NOT NULL DEFAULT '0',
  `Total Berat` double NOT NULL DEFAULT '0',
  `Total HP` int(100) NOT NULL DEFAULT '0',
  `Total HJ` int(100) NOT NULL DEFAULT '0',
  `Grand Total` int(11) NOT NULL DEFAULT '0',
  `Laba` int(100) DEFAULT NULL,
  `Dibayar` int(11) NOT NULL DEFAULT '0',
  `Kembali` int(11) NOT NULL DEFAULT '0',
  `SisaDibayar` int(11) NOT NULL DEFAULT '0',
  `Kode Kasir` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama Kasir` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Kode Pelanggan` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama Pelanggan` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Kode Suplier` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Nama Form` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT 'Penjualan',
  `Tgl` date NOT NULL,
  `No` int(11) NOT NULL,
  `Hitung` varchar(50) COLLATE latin1_general_ci DEFAULT 'Hitung',
  `CetakStruk` varchar(50) COLLATE latin1_general_ci DEFAULT 'Cetak Struk',
  `Waktu` datetime NOT NULL,
  `Stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `penjualan - master`
--

INSERT INTO `penjualan - master` (`ID`, `Faktur`, `No Faktur`, `Diskon`, `Ppn`, `Ongkir`, `Paking`, `Lain - lain`, `Piutang`, `Total Berat`, `Total HP`, `Total HJ`, `Grand Total`, `Laba`, `Dibayar`, `Kembali`, `SisaDibayar`, `Kode Kasir`, `Nama Kasir`, `Kode Pelanggan`, `Nama Pelanggan`, `Kode Suplier`, `Nama Form`, `Tgl`, `No`, `Hitung`, `CetakStruk`, `Waktu`, `Stamp`) VALUES
(1, '', 'J-1', 0, 0, 0, 0, 0, 0, 0, 35000, 41000, 41000, 6000, 200000, 0, 0, 'admin', '', 'C-001', '', '', 'Penjualan', '2013-12-08', 1, 'Hitung', 'Cetak Struk', '0000-00-00 00:00:00', '2013-12-09 04:55:16'),
(2, '', 'J-2', 0, 0, 0, 0, 0, 0, 0, 15000, 18000, 18000, 3000, 20000, 0, 0, 'admin', '', 'C-001', '', '', 'Penjualan', '2013-12-14', 2, 'Hitung', 'Cetak Struk', '0000-00-00 00:00:00', '2013-12-14 13:47:14');

-- --------------------------------------------------------

--
-- Table structure for table `persewaan lapangan - detail`
--

CREATE TABLE `persewaan lapangan - detail` (
  `ID` int(11) NOT NULL,
  `Kode` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `NamaLapangan` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `TglSewa` date DEFAULT NULL,
  `JamSewa` time DEFAULT NULL,
  `HargaSewa` int(50) DEFAULT '0',
  `Status` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `Hitung` varchar(50) COLLATE latin1_general_ci DEFAULT 'Hitung',
  `IDM` int(11) NOT NULL,
  `Waktu` datetime NOT NULL,
  `Stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `persewaan lapangan - detail`
--

INSERT INTO `persewaan lapangan - detail` (`ID`, `Kode`, `NamaLapangan`, `TglSewa`, `JamSewa`, `HargaSewa`, `Status`, `Hitung`, `IDM`, `Waktu`, `Stamp`) VALUES
(1, 'L-001', 'Lapangan Euro', '2013-12-08', '07:00:00', 70000, NULL, 'Hitung', 1, '0000-00-00 00:00:00', '2013-12-08 13:31:24'),
(2, 'L-001', 'Lapangan Euro', '2013-12-09', '07:00:00', 115000, NULL, 'Hitung', 2, '0000-00-00 00:00:00', '2013-12-09 04:27:49'),
(5, 'L-001', 'Lapangan Euro', '2013-12-09', '08:00:00', 115000, NULL, 'Hitung', 2, '0000-00-00 00:00:00', '2013-12-09 04:28:27'),
(6, 'L-001', 'Lapangan Euro', '2013-12-09', '09:00:00', 115000, NULL, 'Hitung', 3, '0000-00-00 00:00:00', '2013-12-09 04:31:09'),
(7, 'L-002', 'Lapangan Olimpico', '2013-12-09', '10:00:00', 90000, NULL, 'Hitung', 4, '0000-00-00 00:00:00', '2013-12-09 04:31:45'),
(8, 'L-001', 'Lapangan Euro', '2013-12-09', '11:00:00', 115000, NULL, 'Hitung', 5, '0000-00-00 00:00:00', '2013-12-09 04:32:00'),
(9, 'L-001', 'Lapangan Euro', '2013-12-09', '12:00:00', 115000, NULL, 'Hitung', 6, '0000-00-00 00:00:00', '2013-12-09 04:32:12'),
(10, 'L-001', 'Lapangan Euro', '2013-12-09', '14:00:00', 115000, NULL, 'Hitung', 7, '0000-00-00 00:00:00', '2013-12-09 04:32:27'),
(11, 'L-001', 'Lapangan Euro', '2013-12-09', '15:00:00', 115000, NULL, 'Hitung', 8, '0000-00-00 00:00:00', '2013-12-09 04:33:51'),
(12, 'L-001', 'Lapangan Euro', '2013-12-09', '16:00:00', 115000, NULL, 'Hitung', 9, '0000-00-00 00:00:00', '2013-12-09 04:34:04'),
(13, 'L-002', 'Lapangan Olimpico', '2013-12-09', '18:00:00', 90000, NULL, 'Hitung', 10, '0000-00-00 00:00:00', '2013-12-09 04:34:16'),
(17, 'L-001', 'Lapangan Euro', '2013-12-14', '08:00:00', 70000, NULL, 'Hitung', 12, '0000-00-00 00:00:00', '2013-12-14 13:09:32');

-- --------------------------------------------------------

--
-- Table structure for table `persewaan lapangan - master`
--

CREATE TABLE `persewaan lapangan - master` (
  `ID` int(11) NOT NULL,
  `No` int(50) NOT NULL,
  `No Faktur` varchar(100) COLLATE latin1_general_ci DEFAULT '0',
  `Faktur` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Tgl` datetime DEFAULT NULL,
  `Kode` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Nama` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Alamat` varchar(225) COLLATE latin1_general_ci DEFAULT NULL,
  `Kota` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Telepon` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Main` int(50) NOT NULL,
  `Total` int(50) DEFAULT '0',
  `Bayar` int(50) DEFAULT '0',
  `Sisa` int(50) DEFAULT '0',
  `Sub Total` int(50) DEFAULT '0',
  `Diskon` int(50) DEFAULT '0',
  `Potongan` int(50) DEFAULT '0',
  `Grand Total` int(50) DEFAULT '0',
  `Kode Kasir` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Nama Kasir` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Status` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT 'Status',
  `Hitung` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT 'Hitung',
  `Cetak Struk` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT 'Cetak Struk',
  `Waktu` datetime NOT NULL,
  `Stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `persewaan lapangan - master`
--

INSERT INTO `persewaan lapangan - master` (`ID`, `No`, `No Faktur`, `Faktur`, `Tgl`, `Kode`, `Nama`, `Alamat`, `Kota`, `Telepon`, `Main`, `Total`, `Bayar`, `Sisa`, `Sub Total`, `Diskon`, `Potongan`, `Grand Total`, `Kode Kasir`, `Nama Kasir`, `Status`, `Hitung`, `Cetak Struk`, `Waktu`, `Stamp`) VALUES
(1, 1, 'F-1', NULL, '2013-12-08 00:00:00', 'C-001', 'Nama1', NULL, NULL, NULL, 0, 0, 30000, 40000, 70000, 0, 10000, 60000, 'admin', NULL, 'Selesai', 'Hitung', 'Cetak Struk', '0000-00-00 00:00:00', '2013-12-08 14:22:24'),
(2, 2, 'F-2', NULL, '2013-12-09 00:00:00', 'C-001', 'Nama1', NULL, NULL, NULL, 0, 0, 80000, 150000, 230000, 0, 0, 230000, 'admin', NULL, 'Booking', 'Hitung', 'Cetak Struk', '0000-00-00 00:00:00', '2013-12-09 04:36:10'),
(3, 3, 'F-3', NULL, '2013-12-09 00:00:00', 'C-002', 'Nama2', NULL, NULL, NULL, 0, 0, 200000, 0, 115000, 0, 0, 115000, 'admin', NULL, 'Selesai', 'Hitung', 'Cetak Struk', '0000-00-00 00:00:00', '2013-12-09 04:36:41'),
(4, 4, 'F-4', NULL, '2013-12-09 00:00:00', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 90000, 90000, 0, 0, 90000, 'admin', NULL, 'Booking', 'Hitung', 'Cetak Struk', '0000-00-00 00:00:00', '2013-12-09 04:31:46'),
(5, 5, 'F-5', NULL, '2013-12-09 00:00:00', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 115000, 115000, 0, 0, 115000, 'admin', NULL, 'Booking', 'Hitung', 'Cetak Struk', '0000-00-00 00:00:00', '2013-12-09 04:32:00'),
(6, 6, 'F-6', NULL, '2013-12-09 00:00:00', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 115000, 115000, 0, 0, 115000, 'admin', NULL, 'Booking', 'Hitung', 'Cetak Struk', '0000-00-00 00:00:00', '2013-12-09 04:32:13'),
(7, 7, 'F-7', NULL, '2013-12-09 00:00:00', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 115000, 115000, 0, 0, 115000, 'admin', NULL, 'Konfirm', 'Hitung', 'Cetak Struk', '0000-00-00 00:00:00', '2013-12-14 13:16:59'),
(8, 8, 'F-8', NULL, '2013-12-09 00:00:00', 'C-002', 'Nama2', NULL, NULL, NULL, 0, 0, 0, 115000, 115000, 0, 0, 115000, 'admin', NULL, 'Selesai', 'Hitung', 'Cetak Struk', '0000-00-00 00:00:00', '2013-12-14 13:16:03'),
(9, 9, 'F-9', NULL, '2013-12-09 00:00:00', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 115000, 115000, 0, 0, 115000, 'admin', NULL, 'Booking', 'Hitung', 'Cetak Struk', '0000-00-00 00:00:00', '2013-12-09 04:34:04'),
(10, 10, 'F-10', NULL, '2013-12-09 00:00:00', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 90000, 90000, 0, 0, 90000, 'admin', NULL, 'Konfirm', 'Hitung', 'Cetak Struk', '0000-00-00 00:00:00', '2013-12-14 13:15:22'),
(12, 11, 'F-11', NULL, '2013-12-14 00:00:00', 'C-001', 'Nama1', NULL, NULL, NULL, 0, 0, 70000, 0, 70000, 0, 0, 70000, 'admin', NULL, 'Selesai', 'Hitung', 'Cetak Struk', '0000-00-00 00:00:00', '2013-12-14 13:51:43'),
(13, 12, 'F-12', NULL, '2013-12-14 00:00:00', NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 'admin', NULL, 'Batal', 'Hitung', 'Cetak Struk', '0000-00-00 00:00:00', '2013-12-14 13:28:32');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `ID` int(11) NOT NULL,
  `Kode` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `NamaToko` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `Pemilik` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Alamat` text COLLATE latin1_general_ci NOT NULL,
  `Kota` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Telepon` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Email` varchar(100) COLLATE latin1_general_ci DEFAULT '',
  `Foto` blob NOT NULL,
  `Serial` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `KeyCode` varchar(100) COLLATE latin1_general_ci DEFAULT NULL,
  `Mobile` int(10) NOT NULL,
  `Waktu` datetime NOT NULL,
  `Stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`ID`, `Kode`, `NamaToko`, `Pemilik`, `Alamat`, `Kota`, `Telepon`, `Email`, `Foto`, `Serial`, `KeyCode`, `Mobile`, `Waktu`, `Stamp`) VALUES
(1, '111', 'Digital Store', 'Digital Store', 'Jl. Candi Mendut', 'Malang', '08123358290', 'digitalstorewebid@gmail.com', '', NULL, '6087c53629ebe81f5303b0ae6be456eb', 0, '0000-00-00 00:00:00', '2013-09-03 16:25:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `2padmin`
--
ALTER TABLE `2padmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `2pbackup`
--
ALTER TABLE `2pbackup`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `daftar lapangan`
--
ALTER TABLE `daftar lapangan`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `daftar pelanggan`
--
ALTER TABLE `daftar pelanggan`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `daftar produk`
--
ALTER TABLE `daftar produk`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `daftar satuan`
--
ALTER TABLE `daftar satuan`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `daftar suplier`
--
ALTER TABLE `daftar suplier`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `lapstok`
--
ALTER TABLE `lapstok`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `lic`
--
ALTER TABLE `lic`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `menusub1`
--
ALTER TABLE `menusub1`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `menusub2`
--
ALTER TABLE `menusub2`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `pembelian - detail`
--
ALTER TABLE `pembelian - detail`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `pembelian - master`
--
ALTER TABLE `pembelian - master`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `penjualan - detail`
--
ALTER TABLE `penjualan - detail`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `penjualan - master`
--
ALTER TABLE `penjualan - master`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `persewaan lapangan - detail`
--
ALTER TABLE `persewaan lapangan - detail`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `persewaan lapangan - master`
--
ALTER TABLE `persewaan lapangan - master`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `2padmin`
--
ALTER TABLE `2padmin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `2pbackup`
--
ALTER TABLE `2pbackup`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `daftar lapangan`
--
ALTER TABLE `daftar lapangan`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `daftar pelanggan`
--
ALTER TABLE `daftar pelanggan`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `daftar produk`
--
ALTER TABLE `daftar produk`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=591;
--
-- AUTO_INCREMENT for table `daftar satuan`
--
ALTER TABLE `daftar satuan`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `daftar suplier`
--
ALTER TABLE `daftar suplier`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `lapstok`
--
ALTER TABLE `lapstok`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `lic`
--
ALTER TABLE `lic`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `menusub1`
--
ALTER TABLE `menusub1`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `menusub2`
--
ALTER TABLE `menusub2`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `pembelian - detail`
--
ALTER TABLE `pembelian - detail`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pembelian - master`
--
ALTER TABLE `pembelian - master`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `penjualan - detail`
--
ALTER TABLE `penjualan - detail`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `penjualan - master`
--
ALTER TABLE `penjualan - master`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `persewaan lapangan - detail`
--
ALTER TABLE `persewaan lapangan - detail`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `persewaan lapangan - master`
--
ALTER TABLE `persewaan lapangan - master`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
